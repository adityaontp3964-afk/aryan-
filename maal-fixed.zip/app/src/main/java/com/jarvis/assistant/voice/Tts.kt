package com.jarvis.assistant.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.jarvis.assistant.data.AssistantState
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/** User-chosen speech settings. [voice] is an exact Android Voice name, or "" for automatic selection. */
data class TtsOptions(val voice: String = "", val rate: Float = 1.0f, val pitch: Float = 1.0f)

/** A voice the installed TTS engine offers, for the settings picker. */
data class VoiceOption(val name: String, val label: String)

/** Android TextToSpeech wrapper. The callback always fires exactly once (done, error, or watchdog timeout). */
class Tts(context: Context) {
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var ready = false
    private var engine: TextToSpeech? = null
    private var current: (() -> Unit)? = null
    private var finished = AtomicBoolean(true)
    private var watchdog: Runnable? = null
    private val audio = context.applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var focus: AudioFocusRequest? = null
    private var initFailed = false
    private var pendingSpeak: (() -> Unit)? = null
    private val speechAttrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()

    val isReady: Boolean get() = ready

    init {
        engine = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (!ready) { initFailed = true; AssistantState.error.value = "Text-to-speech initialise nahi hua" }
            else {
                try { engine?.setAudioAttributes(speechAttrs) } catch (_: Exception) {}
                engine?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { main.post { finish() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { main.post { finish() } }
                })
            }
            // a reply requested while the engine was still starting is spoken now instead of being silently dropped
            val queued = pendingSpeak
            pendingSpeak = null
            queued?.invoke()
        }
    }

    /** True if the engine has usable voice data for [locale] (e.g. hi-IN). Only meaningful once [isReady]. */
    fun hasLanguage(locale: Locale): Boolean {
        val e = engine
        if (!ready || e == null) return false
        return try { e.isLanguageAvailable(locale) >= TextToSpeech.LANG_AVAILABLE } catch (_: Exception) { false }
    }

    /**
     * Voices for Hindi and Indian English (or all English voices if the device has none of those).
     * Android does not expose a voice's gender, so nothing here is labelled "female"; use Test Voice to choose.
     */
    fun voiceOptions(): List<VoiceOption> {
        val e = engine
        if (!ready || e == null) return emptyList()
        val all: List<Voice> = try { e.voices?.toList() ?: emptyList() } catch (_: Exception) { emptyList() }
        var picked = all.filter { it.locale.language == "hi" || (it.locale.language == "en" && it.locale.country == "IN") }
        if (picked.isEmpty()) picked = all.filter { it.locale.language == "en" }
        return picked.sortedWith(compareBy({ it.locale.language != "hi" }, { it.name }))
            .map { v ->
                val tags = buildString {
                    append(v.locale.toLanguageTag())
                    if (v.isNetworkConnectionRequired) append(", online")
                }
                VoiceOption(v.name, "${v.name} ($tags)")
            }
    }

    fun speak(text: String, lang: String, opts: TtsOptions = TtsOptions(), done: () -> Unit) {
        val e = engine
        if (e != null && !ready && !initFailed) {
            // engine still initialising: speak as soon as it is ready, but never wait more than 2.5 s
            val job: () -> Unit = { speak(text, lang, opts, done) }
            pendingSpeak = job
            main.postDelayed({ if (pendingSpeak === job) { pendingSpeak = null; done() } }, 2500L)
            return
        }
        if (!ready || e == null) { done(); return }
        var usable = false
        if (opts.voice.isNotBlank()) {
            val v = try { e.voices?.firstOrNull { it.name == opts.voice } } catch (_: Exception) { null }
            if (v != null) {
                val r = try { e.setVoice(v) } catch (_: Exception) { TextToSpeech.ERROR }
                usable = r == TextToSpeech.SUCCESS
            }
            if (!usable) AssistantState.error.value = "Chuni hui voice nahi mili; automatic voice use ho rahi hai"
        }
        if (!usable) {
            val primary = if (lang == "hi") Locale("hi", "IN") else Locale("en", "IN")
            var r = e.setLanguage(primary)
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                AssistantState.error.value = "${primary.toLanguageTag()} voice data missing; English use ho raha hai"
                r = e.setLanguage(Locale.ENGLISH)
            }
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) { done(); return }
        }
        e.setSpeechRate(opts.rate.coerceIn(0.5f, 2.0f))
        e.setPitch(opts.pitch.coerceIn(0.5f, 2.0f))
        cancelCurrent()
        finished = AtomicBoolean(false)
        current = done
        val w = Runnable { finish() }
        watchdog = w
        main.postDelayed(w, (4000L + text.length * 120L).coerceAtMost(30000L))
        requestFocus()
        val res = e.speak(text, TextToSpeech.QUEUE_FLUSH, null, "friday-${System.nanoTime()}")
        if (res != TextToSpeech.SUCCESS) finish()
    }

    private fun finish() {
        if (!finished.compareAndSet(false, true)) return
        watchdog?.let { main.removeCallbacks(it) }
        abandonFocus()
        val cb = current
        current = null
        cb?.invoke()
    }

    /** Lets music duck while FRIDAY talks, and gives the focus back before the microphone opens again. */
    private fun requestFocus() {
        try {
            val r = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK).setAudioAttributes(speechAttrs).build()
            focus = r
            audio.requestAudioFocus(r)
        } catch (_: Exception) {}
    }

    private fun abandonFocus() {
        val r = focus ?: return
        focus = null
        try { audio.abandonAudioFocusRequest(r) } catch (_: Exception) {}
    }

    private fun cancelCurrent() {
        watchdog?.let { main.removeCallbacks(it) }
        current = null
        finished.set(true)
    }

    fun stop() {
        pendingSpeak = null
        cancelCurrent()
        abandonFocus()
        try { engine?.stop() } catch (_: Exception) {}
    }

    fun shutdown() {
        stop()
        try { engine?.shutdown() } catch (_: Exception) {}
        engine = null
        ready = false
    }
}
