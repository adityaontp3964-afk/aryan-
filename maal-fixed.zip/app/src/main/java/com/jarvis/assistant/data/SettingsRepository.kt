package com.jarvis.assistant.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** How spoken commands are recognised. Wake-word detection is always local (Vosk) regardless of this mode. */
enum class RecogMode { ONLINE, OFFLINE, AUTO }

enum class Level { LOW, MEDIUM, HIGH }
enum class PauseMode { SHORT, NORMAL, LONG }
enum class NoiseMode { NORMAL, NOISY }
enum class AiQuality { FAST, BALANCED, BEST }
enum class RespLength { SHORT, MEDIUM, DETAILED }
enum class FeedbackMode { OFF, SCREEN, SPOKEN }
enum class MatchMode { STRICT, SMART }
enum class WaSendMode { PREPARE_ONLY, AUTO_SEND }
enum class AutoListen { NEVER, AFTER_QUESTIONS, AFTER_EVERY_COMMAND }

const val DEFAULT_WAKE_PHRASE = "hey friday"

data class Prefs(
    val userName: String = "",
    val wakePhrase: String = DEFAULT_WAKE_PHRASE,
    val wakeEnabled: Boolean = true,
    val recogMode: RecogMode = RecogMode.AUTO,
    /** "en" (English), "hi" (Hindi) or "hinglish" (mixed Hindi-English). Vosk only has "en"/"hi" models: see [voskLang]. */
    val recogLang: String = "hinglish",
    val ttsLang: String = "en",     // "en" -> en-IN voice, "hi" -> hi-IN voice
    val ttsVoice: String = "",      // exact Android Voice name; "" = automatic
    val ttsRate: Float = 1.0f,      // 0.5 .. 2.0
    val ttsPitch: Float = 1.0f,     // 0.5 .. 2.0
    val greeting: String = "",
    val aiEnabled: Boolean = false,
    val aiEndpoint: String = "",    // full URL of an OpenAI-compatible /chat/completions endpoint
    val aiModel: String = "",

    // Voice
    val sensitivity: Level = Level.MEDIUM,          // how readily low-confidence / very short results are accepted
    val listenTimeoutSec: Int = 10,                 // 5..30, longest a single command may take
    val pauseMode: PauseMode = PauseMode.NORMAL,    // silence tolerated before the command is considered finished
    val noiseMode: NoiseMode = NoiseMode.NORMAL,
    val wakeSensitivity: Level = Level.MEDIUM,
    val continuousListening: Boolean = true,        // wake-word session stays alive after each command

    // AI performance
    val fastMode: Boolean = false,
    val aiQuality: AiQuality = AiQuality.BALANCED,
    val respLength: RespLength = RespLength.SHORT,
    val aiContextTurns: Int = 4,                    // 0, 2, 4 or 8 earlier turns sent to the AI
    val feedbackMode: FeedbackMode = FeedbackMode.SCREEN,

    // WhatsApp
    val waEnabled: Boolean = true,
    val matchMode: MatchMode = MatchMode.SMART,
    val waConfirm: Boolean = true,
    val waSendMode: WaSendMode = WaSendMode.AUTO_SEND,
    val waErrorSpoken: Boolean = true,
    val countryCode: String = "91",

    // Assistant behaviour
    val keepContext: Boolean = true,                // conversation continuity
    val followUp: Boolean = true,                   // understand follow-up commands from the current task
    val autoListen: AutoListen = AutoListen.AFTER_QUESTIONS,
    val announceDone: Boolean = true,
    val voiceReplies: Boolean = true
) {
    /** Vosk model folder to use: only "en" and "hi" models exist. */
    fun voskLang(): String = if (recogLang == "hi") "hi" else "en"

    /** BCP-47 tag for Android's online recogniser. */
    fun speechTag(): String = if (recogLang == "hi") "hi-IN" else "en-IN"

    /** Extra languages the online recogniser is asked to also accept (a hint; some recognisers ignore it). */
    fun extraSpeechLangs(): List<String> = when (recogLang) {
        "hinglish" -> listOf("hi-IN")
        "hi" -> listOf("en-IN")
        else -> emptyList()
    }

    /** Silence (ms) after which a command is treated as finished. */
    fun pauseMs(): Int = when (pauseMode) { PauseMode.SHORT -> 1000; PauseMode.NORMAL -> 1800; PauseMode.LONG -> 3000 }

    /** Clamps every value to its valid range and enforces rules that must always hold. */
    fun validated(): Prefs {
        val lang = if (recogLang == "en" || recogLang == "hi" || recogLang == "hinglish") recogLang else "hinglish"
        val cc = if (countryCode.length in 1..3 && countryCode.all { it.isDigit() }) countryCode else "91"
        val turns = listOf(0, 2, 4, 8).minByOrNull { Math.abs(it - aiContextTurns) } ?: 4
        return copy(
            recogLang = lang,
            listenTimeoutSec = listenTimeoutSec.coerceIn(5, 30),
            countryCode = cc,
            aiContextTurns = turns,
            ttsRate = ttsRate.coerceIn(0.5f, 2.0f),
            ttsPitch = ttsPitch.coerceIn(0.5f, 2.0f),
            // Automatic sending is only allowed together with a spoken confirmation.
            waConfirm = if (waSendMode == WaSendMode.AUTO_SEND) true else waConfirm
        )
    }
}

private fun <T : Enum<T>> enumOf(values: Array<T>, name: String?, default: T): T =
    values.firstOrNull { it.name == name } ?: default

class SettingsRepository(context: Context) {
    private val sp = context.getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)
    private val _prefs = MutableStateFlow(load())
    val prefs: StateFlow<Prefs> = _prefs

    private fun load(): Prefs {
        val d = Prefs()
        return Prefs(
            userName = sp.getString("userName", "") ?: "",
            // Settings saved by the JARVIS build still hold the old default phrase; move them to the FRIDAY default.
            wakePhrase = (sp.getString("wakePhrase", DEFAULT_WAKE_PHRASE) ?: DEFAULT_WAKE_PHRASE)
                .let { if (it.isBlank() || it == "hey jarvis") DEFAULT_WAKE_PHRASE else it },
            wakeEnabled = sp.getBoolean("wakeEnabled", true),
            recogMode = enumOf(RecogMode.values(), sp.getString("recogMode", null), RecogMode.AUTO),
            recogLang = sp.getString("recogLang", d.recogLang) ?: d.recogLang,
            ttsLang = sp.getString("ttsLang", "en") ?: "en",
            ttsVoice = sp.getString("ttsVoice", "") ?: "",
            ttsRate = sp.getFloat("ttsRate", 1.0f),
            ttsPitch = sp.getFloat("ttsPitch", 1.0f),
            greeting = sp.getString("greeting", "") ?: "",
            aiEnabled = sp.getBoolean("aiEnabled", false),
            aiEndpoint = sp.getString("aiEndpoint", "") ?: "",
            aiModel = sp.getString("aiModel", "") ?: "",

            sensitivity = enumOf(Level.values(), sp.getString("sensitivity", null), d.sensitivity),
            listenTimeoutSec = sp.getInt("listenTimeoutSec", d.listenTimeoutSec),
            pauseMode = enumOf(PauseMode.values(), sp.getString("pauseMode", null), d.pauseMode),
            noiseMode = enumOf(NoiseMode.values(), sp.getString("noiseMode", null), d.noiseMode),
            wakeSensitivity = enumOf(Level.values(), sp.getString("wakeSensitivity", null), d.wakeSensitivity),
            continuousListening = sp.getBoolean("continuousListening", d.continuousListening),

            fastMode = sp.getBoolean("fastMode", d.fastMode),
            aiQuality = enumOf(AiQuality.values(), sp.getString("aiQuality", null), d.aiQuality),
            respLength = enumOf(RespLength.values(), sp.getString("respLength", null), d.respLength),
            aiContextTurns = sp.getInt("aiContextTurns", d.aiContextTurns),
            feedbackMode = enumOf(FeedbackMode.values(), sp.getString("feedbackMode", null), d.feedbackMode),

            waEnabled = sp.getBoolean("waEnabled", d.waEnabled),
            matchMode = enumOf(MatchMode.values(), sp.getString("matchMode", null), d.matchMode),
            waConfirm = sp.getBoolean("waConfirm", d.waConfirm),
            waSendMode = enumOf(WaSendMode.values(), sp.getString("waSendMode", null), d.waSendMode),
            waErrorSpoken = sp.getBoolean("waErrorSpoken", d.waErrorSpoken),
            countryCode = sp.getString("countryCode", d.countryCode) ?: d.countryCode,

            keepContext = sp.getBoolean("keepContext", d.keepContext),
            followUp = sp.getBoolean("followUp", d.followUp),
            autoListen = enumOf(AutoListen.values(), sp.getString("autoListen", null), d.autoListen),
            announceDone = sp.getBoolean("announceDone", d.announceDone),
            voiceReplies = sp.getBoolean("voiceReplies", d.voiceReplies)
        ).validated()
    }

    fun update(transform: (Prefs) -> Prefs) {
        val n = transform(_prefs.value).validated()
        _prefs.value = n
        sp.edit()
            .putString("userName", n.userName)
            .putString("wakePhrase", n.wakePhrase)
            .putBoolean("wakeEnabled", n.wakeEnabled)
            .putString("recogMode", n.recogMode.name)
            .putString("recogLang", n.recogLang)
            .putString("ttsLang", n.ttsLang)
            .putString("ttsVoice", n.ttsVoice)
            .putFloat("ttsRate", n.ttsRate)
            .putFloat("ttsPitch", n.ttsPitch)
            .putString("greeting", n.greeting)
            .putBoolean("aiEnabled", n.aiEnabled)
            .putString("aiEndpoint", n.aiEndpoint)
            .putString("aiModel", n.aiModel)
            .putString("sensitivity", n.sensitivity.name)
            .putInt("listenTimeoutSec", n.listenTimeoutSec)
            .putString("pauseMode", n.pauseMode.name)
            .putString("noiseMode", n.noiseMode.name)
            .putString("wakeSensitivity", n.wakeSensitivity.name)
            .putBoolean("continuousListening", n.continuousListening)
            .putBoolean("fastMode", n.fastMode)
            .putString("aiQuality", n.aiQuality.name)
            .putString("respLength", n.respLength.name)
            .putInt("aiContextTurns", n.aiContextTurns)
            .putString("feedbackMode", n.feedbackMode.name)
            .putBoolean("waEnabled", n.waEnabled)
            .putString("matchMode", n.matchMode.name)
            .putBoolean("waConfirm", n.waConfirm)
            .putString("waSendMode", n.waSendMode.name)
            .putBoolean("waErrorSpoken", n.waErrorSpoken)
            .putString("countryCode", n.countryCode)
            .putBoolean("keepContext", n.keepContext)
            .putBoolean("followUp", n.followUp)
            .putString("autoListen", n.autoListen.name)
            .putBoolean("announceDone", n.announceDone)
            .putBoolean("voiceReplies", n.voiceReplies)
            .apply()
    }

    fun saveApiKey(key: String) {
        sp.edit().putString("aiKey", if (key.isBlank()) "" else SecretStore.encrypt(key.trim())).apply()
    }

    fun apiKey(): String =
        sp.getString("aiKey", "")?.takeIf { it.isNotEmpty() }?.let { SecretStore.decrypt(it) } ?: ""

    fun hasApiKey(): Boolean = !sp.getString("aiKey", "").isNullOrEmpty()

    fun reset() {
        sp.edit().clear().apply()
        _prefs.value = Prefs()
    }
}
