package com.jarvis.assistant.command

/** Genuine outcome of an action; never SUCCESS unless the result was actually checked or the OS accepted the request. */
enum class ActionStatus {
    ACTION_STARTED, ACTION_SUCCESS, ACTION_FAILED, NEEDS_CONFIRMATION, NEEDS_PERMISSION,
    TARGET_NOT_FOUND, AMBIGUOUS_CONTACT, UNSUPPORTED_ACTION,
    /** WhatsApp chat is open with the exact text typed in, but it was NOT sent. */
    MESSAGE_PREPARED
}

data class CommandResult(
    val success: Boolean,
    val message: String,
    val requiresConfirmation: Boolean = false,
    val followUp: String? = null,
    val source: String = "LOCAL",
    val stopSession: Boolean = false,
    val status: ActionStatus = if (success) ActionStatus.ACTION_SUCCESS else ActionStatus.ACTION_FAILED,
    /** The user finished or cancelled the task: do not keep listening for follow-ups. */
    val endsTask: Boolean = false
)

class ConfirmationManager {
    @Volatile private var pending: (suspend () -> CommandResult)? = null
    val hasPending: Boolean get() = pending != null
    fun set(action: suspend () -> CommandResult) { pending = action }
    fun take(): (suspend () -> CommandResult)? { val p = pending; pending = null; return p }
    fun clear(): Boolean { val had = pending != null; pending = null; return had }
}

data class ContactOption(val label: String, val name: String, val number: String)

/** What the assistant is waiting for in the user's NEXT utterance (besides yes/no confirmations). */
sealed class Awaiting {
    /** Dictation: the next utterance is typed into the focused text field. */
    object TypeText : Awaiting()
    /** Text of a WhatsApp message for [contact] (null = chat selected earlier). */
    data class MessageText(val contact: String?) : Awaiting()
    /** Several WhatsApp contacts matched; the user must pick one. [message] is set if a send is in progress. */
    data class ContactChoice(val candidates: List<String>, val message: String?) : Awaiting()
    /** Several Android contacts matched; the user must pick one. [message] null = only open the chat. */
    data class ContactPick(val options: List<ContactOption>, val message: String?) : Awaiting()
    /** "search karo" with no text: the next utterance is the web search query. */
    object SearchQuery : Awaiting()
}

/** Short-lived task memory: the last WhatsApp chat FRIDAY opened (so "usko message bhejo" works) and the app being used. */
object AssistantContext {
    private const val TTL_MS = 10 * 60 * 1000L
    @Volatile private var lastContact: String? = null
    @Volatile private var lastNumber: String? = null
    @Volatile private var lastAt = 0L
    @Volatile private var lastApp: String? = null
    @Volatile private var appAt = 0L

    fun setContact(name: String, waNumber: String? = null) { lastContact = name; lastNumber = waNumber; lastAt = System.currentTimeMillis() }
    fun contact(): String? = if (System.currentTimeMillis() - lastAt <= TTL_MS) lastContact else null
    /** wa.me-format number of [contact], if the chat was opened through the Contacts-based route. */
    fun contactNumber(): String? = if (contact() != null) lastNumber else null

    fun setApp(name: String) { lastApp = name; appAt = System.currentTimeMillis() }
    fun app(): String? = if (System.currentTimeMillis() - appAt <= TTL_MS) lastApp else null

    fun clear() { lastContact = null; lastNumber = null; lastApp = null }
}
