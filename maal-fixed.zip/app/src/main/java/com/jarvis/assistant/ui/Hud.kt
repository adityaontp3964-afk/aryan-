package com.jarvis.assistant.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.assistant.data.VoiceState
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

object Hud {
    val Bg = Color(0xFF0A0E14)
    val Panel = Color(0xFF0E1622)
    val Cyan = Color(0xFF00D4FF)
    val Blue = Color(0xFF2E7BFF)
    val Dim = Color(0xFF1B2A3A)
    val Txt = Color(0xFFBFEFFF)
    val Sub = Color(0xFF7C93A8)
    val Warn = Color(0xFFFFB020)
    val Bad = Color(0xFFFF4D5E)
    val Good = Color(0xFF38F2A0)
}

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Hud.Cyan, secondary = Hud.Blue, background = Hud.Bg,
            surface = Hud.Panel, onSurface = Hud.Txt, onBackground = Hud.Txt
        ),
        content = content
    )
}

@Composable
fun HudText(
    text: String, modifier: Modifier = Modifier, size: TextUnit = 14.sp, color: Color = Hud.Txt,
    spacing: TextUnit = 1.sp, weight: FontWeight = FontWeight.Normal, align: TextAlign = TextAlign.Start, glow: Boolean = false
) {
    Text(
        text, modifier = modifier, textAlign = align,
        style = TextStyle(
            color = color, fontSize = size, letterSpacing = spacing, fontWeight = weight, fontFamily = FontFamily.Monospace,
            shadow = if (glow) Shadow(Hud.Cyan, Offset.Zero, 18f) else null
        )
    )
}

@Composable
fun HudPanel(title: String, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .background(Hud.Panel.copy(alpha = 0.75f))
            .border(1.dp, Hud.Cyan.copy(alpha = 0.3f))
            .drawBehind {
                val l = 14.dp.toPx(); val w = 2.dp.toPx(); val c = Hud.Cyan
                drawLine(c, Offset(0f, 0f), Offset(l, 0f), w); drawLine(c, Offset(0f, 0f), Offset(0f, l), w)
                drawLine(c, Offset(size.width, 0f), Offset(size.width - l, 0f), w); drawLine(c, Offset(size.width, 0f), Offset(size.width, l), w)
                drawLine(c, Offset(0f, size.height), Offset(l, size.height), w); drawLine(c, Offset(0f, size.height), Offset(0f, size.height - l), w)
                drawLine(c, Offset(size.width, size.height), Offset(size.width - l, size.height), w)
                drawLine(c, Offset(size.width, size.height), Offset(size.width, size.height - l), w)
            }
            .padding(12.dp)
    ) {
        HudText(title, size = 11.sp, color = Hud.Cyan, spacing = 2.sp)
        Spacer(Modifier.height(8.dp))
        content()
    }
}

@Composable
fun HudButton(label: String, onClick: () -> Unit, modifier: Modifier = Modifier, color: Color = Hud.Cyan, enabled: Boolean = true) {
    val c = if (enabled) color else Hud.Sub
    Box(
        modifier
            .defaultMinSize(minHeight = 48.dp)
            .border(1.dp, c, RoundedCornerShape(6.dp))
            .background(c.copy(alpha = 0.10f), RoundedCornerShape(6.dp))
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center
    ) { HudText(label, size = 12.sp, color = c, spacing = 1.5.sp, weight = FontWeight.Bold, align = TextAlign.Center) }
}

@Composable
fun HudChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val c = if (selected) Hud.Cyan else Hud.Sub
    Box(
        Modifier.defaultMinSize(minHeight = 40.dp)
            .border(1.dp, c, RoundedCornerShape(20.dp))
            .background(if (selected) Hud.Cyan.copy(alpha = 0.18f) else Color.Transparent, RoundedCornerShape(20.dp))
            .clickable(role = Role.RadioButton, onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) { HudText(label, size = 12.sp, color = c) }
}

@Composable
fun HudField(value: String, onChange: (String) -> Unit, label: String, password: Boolean = false, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth()) {
        HudText(label, size = 11.sp, color = Hud.Sub)
        Spacer(Modifier.height(4.dp))
        BasicTextField(
            value = value, onValueChange = onChange, singleLine = true,
            textStyle = TextStyle(color = Hud.Txt, fontSize = 15.sp, fontFamily = FontFamily.Monospace),
            cursorBrush = SolidColor(Hud.Cyan),
            visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
            modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 48.dp)
                .border(1.dp, Hud.Cyan.copy(alpha = 0.4f), RoundedCornerShape(6.dp)).padding(12.dp)
                .semantics { contentDescription = label }
        )
    }
}

@Composable
fun StatusRow(label: String, value: String, ok: Boolean?, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        val c = when (ok) { true -> Hud.Good; false -> Hud.Warn; null -> Hud.Sub }
        Box(Modifier.size(8.dp).background(c, RoundedCornerShape(4.dp)))
        Spacer(Modifier.width(10.dp))
        HudText(label, size = 12.sp, color = Hud.Sub, modifier = Modifier.weight(1f))
        HudText(value, size = 12.sp, color = c, weight = FontWeight.Bold)
    }
}

/** Voice-reactive core. Animation intensity follows the assistant state (it is not driven by raw microphone amplitude). */
@Composable
fun JarvisCore(state: VoiceState, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "core")
    val rot by t.animateFloat(0f, 360f, infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "rot")
    val rot2 by t.animateFloat(360f, 0f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "rot2")
    val phase by t.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(1200, easing = LinearEasing)), label = "ph")
    val target = when (state) {
        VoiceState.LISTENING -> 1f; VoiceState.SPEAKING -> 0.8f; VoiceState.PROCESSING -> 0.55f
        VoiceState.AWAITING_CONFIRMATION -> 0.65f; VoiceState.INITIALIZING -> 0.4f
        VoiceState.WAITING_FOR_WAKE_WORD -> 0.2f; else -> 0.05f
    }
    val amp by animateFloatAsState(target, tween(400), label = "amp")
    val main = if (state == VoiceState.ERROR) Hud.Bad else Hud.Cyan
    Canvas(modifier.aspectRatio(1f).semantics { contentDescription = "FRIDAY core, ${state.name.lowercase().replace('_', ' ')}" }) {
        val c = center
        val r = size.minDimension / 2f
        drawCircle(Brush.radialGradient(listOf(main.copy(alpha = 0.10f + 0.25f * amp), Color.Transparent), center = c, radius = r), radius = r)
        drawCircle(main.copy(alpha = 0.5f), radius = r * 0.97f, style = Stroke(1.5.dp.toPx()))
        rotate(rot, c) {
            for (i in 0 until 4) drawArc(
                main, startAngle = i * 90f + 5f, sweepAngle = 50f, useCenter = false,
                topLeft = Offset(c.x - r * 0.88f, c.y - r * 0.88f), size = Size(r * 1.76f, r * 1.76f),
                style = Stroke(3.dp.toPx(), cap = StrokeCap.Round)
            )
        }
        rotate(rot2, c) {
            for (i in 0 until 60) {
                val a = (i * 6.0 * PI / 180.0).toFloat()
                val len = if (i % 5 == 0) r * 0.07f else r * 0.035f
                val r1 = r * 0.78f
                drawLine(Hud.Blue.copy(alpha = 0.8f), Offset(c.x + cos(a) * r1, c.y + sin(a) * r1),
                    Offset(c.x + cos(a) * (r1 - len), c.y + sin(a) * (r1 - len)), 1.dp.toPx())
            }
        }
        val n = 48
        for (i in 0 until n) {
            val a = (2.0 * PI * i / n).toFloat()
            val h = r * (0.05f + 0.15f * amp * (0.5f + 0.5f * sin(phase * 2f + i * 0.7f)))
            val inner = r * 0.5f
            drawLine(main, Offset(c.x + cos(a) * inner, c.y + sin(a) * inner),
                Offset(c.x + cos(a) * (inner + h), c.y + sin(a) * (inner + h)), 2.dp.toPx(), StrokeCap.Round)
        }
        drawCircle(main.copy(alpha = 0.12f + 0.2f * amp), radius = r * 0.38f)
        drawCircle(main, radius = r * 0.38f, style = Stroke(1.dp.toPx()))
        drawCircle(main, radius = r * 0.06f)
    }
}

@Composable
fun WaveBars(state: VoiceState, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "wave")
    val phase by t.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(1000, easing = LinearEasing)), label = "wp")
    val target = when (state) {
        VoiceState.LISTENING -> 1f; VoiceState.SPEAKING -> 0.8f; VoiceState.PROCESSING -> 0.4f
        VoiceState.AWAITING_CONFIRMATION -> 0.5f; VoiceState.WAITING_FOR_WAKE_WORD -> 0.12f; else -> 0.03f
    }
    val amp by animateFloatAsState(target, tween(300), label = "wa")
    Canvas(modifier.fillMaxWidth().height(40.dp).semantics { contentDescription = "Voice activity indicator" }) {
        val n = 40
        val slot = size.width / n
        for (i in 0 until n) {
            val h = size.height * (0.08f + 0.92f * amp * abs(sin(phase + i * 0.5f)))
            val x = slot * i + slot / 2f
            drawLine(Hud.Cyan.copy(alpha = 0.85f), Offset(x, (size.height - h) / 2f), Offset(x, (size.height + h) / 2f), 3.dp.toPx(), StrokeCap.Round)
        }
    }
}
