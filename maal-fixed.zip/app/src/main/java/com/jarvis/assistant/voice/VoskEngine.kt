package com.jarvis.assistant.voice

import android.content.Context
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File

/**
 * Wraps Vosk. Only one SpeechService (one microphone session) can exist at a time.
 * Loaded models are cached for the whole process (loading a 40-50 MB model takes seconds), so restarting the voice
 * session does not reload them; [clearCache] frees them when the system is short on memory.
 */
class VoskEngine(private val context: Context) {
    private var service: SpeechService? = null
    private var recognizer: Recognizer? = null

    init { LibVosk.setLogLevel(LogLevel.WARNINGS) }

    /** Returns the loaded model for [lang] or null if the model folder is missing. Blocking: call off the main thread. */
    fun model(lang: String): Model? = synchronized(cache) {
        cache[lang]?.let { return it }
        val dir = modelDir(context, lang)
        if (!hasModel(context, lang)) return null
        val m = Model(dir.absolutePath)
        cache[lang] = m
        return m
    }

    /** Starts a recognition session. Any previous session is cancelled first. May throw if the microphone is unavailable. */
    @Synchronized
    fun listen(model: Model, timeoutMs: Int, listener: RecognitionListener) {
        stop()
        val rec = Recognizer(model, 16000f)
        val svc = SpeechService(rec, 16000f)
        recognizer = rec
        service = svc
        val started = if (timeoutMs > 0) svc.startListening(listener, timeoutMs) else svc.startListening(listener)
        if (!started) {
            stop()
            throw IllegalStateException("Microphone is busy or unavailable")
        }
    }

    /** Stops microphone capture immediately and releases the recognizer. Safe to call repeatedly. */
    @Synchronized
    fun stop() {
        try { service?.cancel() } catch (_: Exception) {}
        try { service?.shutdown() } catch (_: Exception) {}
        service = null
        try { recognizer?.close() } catch (_: Exception) {}
        recognizer = null
    }

    /** Releases the microphone. Models stay cached for the next session. */
    @Synchronized
    fun release() {
        stop()
    }

    companion object {
        private val cache = HashMap<String, Model>()

        /** Closes all cached models. Only call while no voice session is running. */
        fun clearCache() = synchronized(cache) {
            cache.values.forEach { try { it.close() } catch (_: Exception) {} }
            cache.clear()
        }

        fun modelDir(context: Context, lang: String): File =
            File(context.getExternalFilesDir(null) ?: context.filesDir, "models/$lang")

        fun hasModel(context: Context, lang: String): Boolean =
            File(modelDir(context, lang), "am").isDirectory
    }
}
