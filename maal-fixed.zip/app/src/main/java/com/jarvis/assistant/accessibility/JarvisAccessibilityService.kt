package com.jarvis.assistant.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

enum class TypeOutcome { OK, NO_FIELD, PASSWORD, FAILED }

/**
 * FRIDAY's hands: global actions, gestures, and reading/clicking/typing in the foreground app's accessible UI.
 * Nothing is observed passively ([onAccessibilityEvent] does nothing); the screen is only inspected while FRIDAY is
 * executing a command the user gave. The user must enable this service manually in Android Settings.
 */
class JarvisAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* no passive monitoring */ }
    override fun onInterrupt() {}
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }

    // ---- gestures and global actions ----

    fun swipe(up: Boolean): Boolean {
        val m = resources.displayMetrics
        val x = m.widthPixels / 2f
        val from = m.heightPixels * (if (up) 0.78f else 0.25f)
        val to = m.heightPixels * (if (up) 0.25f else 0.78f)
        val path = Path().apply { moveTo(x, from); lineTo(x, to) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 260)).build()
        return dispatchGesture(g, null, null)
    }

    fun global(action: Int): Boolean = performGlobalAction(action)

    fun lockScreen(): Boolean =
        Build.VERSION.SDK_INT >= 28 && performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)

    // ---- reading the screen ----

    /** Package of the app currently in the foreground, if the system exposes it. */
    fun currentPackage(): String? = rootInActiveWindow?.packageName?.toString()

    fun label(n: AccessibilityNodeInfo): String = (n.contentDescription ?: n.text)?.toString()?.trim() ?: ""

    private fun walk(node: AccessibilityNodeInfo?, depth: Int = 0, visit: (AccessibilityNodeInfo) -> Boolean): Boolean {
        if (node == null || depth > 40) return false
        if (visit(node)) return true
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            if (walk(c, depth + 1, visit)) return true
        }
        return false
    }

    /** All nodes under [root] matching [predicate] (document order). */
    fun collect(root: AccessibilityNodeInfo?, predicate: (AccessibilityNodeInfo) -> Boolean): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        walk(root) { n -> if (predicate(n)) out.add(n); false }
        return out
    }

    /** First node whose content description / text equals one of [labels] (case-insensitive). */
    fun findByLabel(root: AccessibilityNodeInfo?, vararg labels: String): AccessibilityNodeInfo? =
        collect(root) { n ->
            val l = label(n).lowercase()
            l.isNotEmpty() && labels.any { it.lowercase() == l }
        }.firstOrNull()

    // ---- acting on nodes ----

    /** Clicks [node], or its nearest clickable ancestor. True only if Android accepted the click. */
    fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        var hops = 0
        while (n != null && hops < 6) {
            if (n.isClickable && n.isEnabled) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
            hops++
        }
        return false
    }

    fun findEditable(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (root == null) return null
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (focused != null && focused.isEditable) return focused
        return collect(root) { it.isEditable && it.isVisibleToUser }.firstOrNull()
    }

    /** Types into the focused (or first visible) text field. Refuses password fields. */
    fun typeText(text: String, append: Boolean): TypeOutcome {
        val node = findEditable(rootInActiveWindow) ?: return TypeOutcome.NO_FIELD
        return setTextOn(node, text, append)
    }

    fun setTextOn(node: AccessibilityNodeInfo, text: String, append: Boolean): TypeOutcome {
        if (node.isPassword) return TypeOutcome.PASSWORD
        var existing = ""
        if (append && !node.isShowingHintText) existing = node.text?.toString() ?: ""
        val prefix = if (existing.isNotEmpty() && !existing.endsWith(" ")) "$existing " else existing
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, prefix + text)
        if (!node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return TypeOutcome.FAILED
        node.refresh()
        val now = node.text?.toString() ?: ""
        return if (now.contains(text.trim(), ignoreCase = true)) TypeOutcome.OK else TypeOutcome.FAILED
    }

    fun clearText(): TypeOutcome {
        val node = findEditable(rootInActiveWindow) ?: return TypeOutcome.NO_FIELD
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
        if (!node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return TypeOutcome.FAILED
        node.refresh()
        return if (node.isShowingHintText || node.text.isNullOrEmpty()) TypeOutcome.OK else TypeOutcome.FAILED
    }

    /** Presses the keyboard "search/enter" action (Android 11+) or clicks a visible "Search" button. */
    fun submitSearch(): Boolean {
        val root = rootInActiveWindow ?: return false
        val field = findEditable(root)
        if (field != null && Build.VERSION.SDK_INT >= 30 &&
            field.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)) return true
        val button = collect(root) { n ->
            val l = label(n).lowercase()
            !n.isEditable && (l == "search" || l == "go" || l == "खोजें")
        }.firstOrNull() ?: return false
        return clickNode(button)
    }

    /** Scrolls the largest visible scrollable view. False if there is none (caller may fall back to a swipe gesture). */
    fun scrollScreen(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val target = collect(root) { it.isScrollable && it.isVisibleToUser }.maxByOrNull {
            val r = Rect()
            it.getBoundsInScreen(r)
            r.width().toLong() * r.height()
        } ?: return false
        return target.performAction(
            if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        )
    }

    /** Clicks WhatsApp's Send button if it is currently visible. Returns true only if a click was performed. */
    fun clickWhatsAppSend(): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString()?.startsWith("com.whatsapp") != true) return false
        val target = findByLabel(root, "send", "भेजें") ?: return false
        return clickNode(target)
    }

    companion object {
        @Volatile var instance: JarvisAccessibilityService? = null
    }
}
