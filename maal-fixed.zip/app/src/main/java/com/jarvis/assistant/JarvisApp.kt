package com.jarvis.assistant

import android.app.Application
import android.content.ComponentCallbacks2
import com.jarvis.assistant.data.AssistantState
import com.jarvis.assistant.data.HistoryRepository
import com.jarvis.assistant.data.SettingsRepository
import com.jarvis.assistant.data.VoiceState
import com.jarvis.assistant.voice.VoskEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class JarvisApp : Application() {
    val settings by lazy { SettingsRepository(this) }
    val history by lazy { HistoryRepository(this) }
    /** App-level scope for work that must outlive a screen (model download, AI test). */
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        // Cached voice models are large; drop them when the app is in the background under memory pressure and no session uses them.
        val idle = AssistantState.state.value.let { it == VoiceState.IDLE || it == VoiceState.STOPPED || it == VoiceState.ERROR }
        if (level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND && idle) VoskEngine.clearCache()
    }
}
