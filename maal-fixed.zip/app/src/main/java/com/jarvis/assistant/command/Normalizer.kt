package com.jarvis.assistant.command

/**
 * Hinglish normalisation: lowercase, strip punctuation/fillers, map common Devanagari words to Roman,
 * then apply speech-recognition mishearing aliases.
 *
 * Aliases come in two kinds (see [Aliases]):
 *  - safe aliases ("you tube", "whats app") are replaced everywhere;
 *  - context aliases ("you do", "what s up", "coal") are replaced ONLY when the neighbouring words make the
 *    command reading likely, so "what do you do" or "I love you too" stay untouched.
 *
 * Pure Kotlin (no Android dependencies) so it can be unit-tested on the JVM.
 */
object Normalizer {
    private class Alias(val phrase: List<String>, val target: String, val context: ((prev: String?, next: String?) -> Boolean)?)

    private fun safe(target: String, vararg phrases: String) =
        phrases.map { Alias(it.split(" "), target, null) }

    private fun contextual(target: String, ctx: (String?, String?) -> Boolean, vararg phrases: String) =
        phrases.map { Alias(it.split(" "), target, ctx) }

    /** Words that normally come right before an app name ("open you do"). */
    private val appBefore = setOf("open", "launch", "start", "play", "search", "on", "par", "pe", "per", "mein", "me")
    /** Words that normally come right after an app name ("you do khol"). */
    private val appAfter = setOf("khol", "kholo", "kholna", "open", "launch", "chalao", "chala", "chalu", "par", "pe", "per",
        "mein", "me", "app", "search", "play", "karo", "kar", "start")
    private val settingsAfter = setOf("settings", "setting", "khol", "kholo", "on", "off", "chalu", "band", "open", "connect")
    private val verbTail = setOf("karo", "kar", "do", "de", "dena")

    private val appCtx: (String?, String?) -> Boolean = { prev, next ->
        (prev != null && prev in appBefore) || (next != null && next in appAfter)
    }
    private val settingsCtx: (String?, String?) -> Boolean = { _, next -> next != null && next in settingsAfter }
    /** A mis-heard "khol" must follow some object and end the phrase (or be followed by karo/do): "youtube coal". */
    private val openVerbCtx: (String?, String?) -> Boolean = { prev, next ->
        prev != null && (next == null || next in verbTail)
    }

    // Longest phrases first so "what s up" wins over any shorter overlapping alias.
    private val aliases: List<Alias> = (
        safe("youtube", "you tube", "u tube", "you tub", "yu tube", "utube", "youtub", "yutube", "yutub", "you2be") +
        contextual("youtube", appCtx, "you do", "you to", "you too", "u do", "you doo", "you tu") +
        safe("whatsapp", "whats app", "what s app", "whatsap", "watsapp", "wats app", "watsap") +
        contextual("whatsapp", appCtx, "what s up", "whats up", "what sup", "what up", "whatsup") +
        safe("instagram", "insta gram", "insta", "instagrams") +
        safe("bluetooth", "blue tooth", "blue tooth s") +
        safe("wifi", "wi fi", "why fi", "vi fi", "wifi s") +
        contextual("wifi", settingsCtx, "wife i") +
        safe("google", "google s", "goggle") +
        safe("flashlight", "flash light", "flash lite") +
        safe("volume", "wolume", "volyum") +
        contextual("khol", openVerbCtx, "kohl", "coal", "kol", "khul", "kool") +
        safe("khol", "kholo")
        ).sortedByDescending { it.phrase.size }

    private val devanagari = mapOf(
        "खोल" to "khol", "खोलो" to "kholo", "खोलना" to "kholna",
        "यूट्यूब" to "youtube", "यूट्यब" to "youtube",
        "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "वाट्सऐप" to "whatsapp", "व्हॉट्सऐप" to "whatsapp",
        "गूगल" to "google", "सर्च" to "search", "इंस्टाग्राम" to "instagram", "क्रोम" to "chrome",
        "समय" to "samay", "टाइम" to "time", "तारीख" to "tarikh", "तुम्हारा" to "tumhara", "तेरा" to "tera",
        "आपका" to "aapka", "मेरा" to "mera", "नाम" to "naam", "क्या" to "kya", "है" to "hai",
        "वाईफाई" to "wifi", "वाइफाई" to "wifi", "ब्लूटूथ" to "bluetooth", "सेटिंग" to "settings", "सेटिंग्स" to "settings",
        "लॉक" to "lock", "हाँ" to "haan", "हां" to "haan", "नहीं" to "nahi", "रुको" to "ruko",
        "बंद" to "band", "करो" to "karo", "कर" to "kar", "दो" to "do", "भेजो" to "bhejo",
        "मैसेज" to "message", "को" to "ko", "पर" to "par", "में" to "mein", "कैमरा" to "camera",
        "नमस्ते" to "namaste", "धन्यवाद" to "dhanyavad", "शुक्रिया" to "shukriya", "अगली" to "agli", "रील" to "reel",
        // volume / torch / media (added for FRIDAY)
        "वॉल्यूम" to "volume", "वॉल्युम" to "volume", "आवाज" to "awaaz", "आवाज़" to "awaaz",
        "बढ़ाओ" to "badhao", "बढाओ" to "badhao", "बढ़ा" to "badha", "घटाओ" to "ghatao", "कम" to "kam",
        "टॉर्च" to "torch", "फ्लैशलाइट" to "flashlight", "ऑन" to "on", "ऑफ" to "off", "चालू" to "chalu",
        "चलाओ" to "chalao", "चला" to "chala", "गाना" to "gaana", "गाने" to "gaane", "बताओ" to "batao", "मुझे" to "mujhe",
        "म्यूट" to "mute"
    )

    private val fillers = setOf("please", "pls", "plz", "sir", "jarvis", "friday", "zara", "yaar", "bhai", "ji", "hey")

    fun normalize(raw: String): String {
        val cleaned = raw.lowercase().replace(Regex("[^\\p{L}\\p{M}\\p{N}\\s]"), " ").replace(Regex("\\s+"), " ").trim()
        if (cleaned.isEmpty()) return ""
        val tokens = cleaned.split(" ").filter { it.isNotEmpty() }.map { devanagari[it] ?: it }
        return applyAliases(tokens).filter { it !in fillers }.joinToString(" ")
    }

    private fun applyAliases(tokens: List<String>): List<String> {
        val out = ArrayList<String>()
        var i = 0
        while (i < tokens.size) {
            var hit: Alias? = null
            for (a in aliases) {
                val n = a.phrase.size
                if (i + n > tokens.size) continue
                if (tokens.subList(i, i + n) != a.phrase) continue
                val ctx = a.context
                if (ctx != null && !ctx(tokens.getOrNull(i - 1), tokens.getOrNull(i + n))) continue
                hit = a
                break
            }
            if (hit != null) { out.add(hit.target); i += hit.phrase.size } else { out.add(tokens[i]); i++ }
        }
        return out
    }
}
