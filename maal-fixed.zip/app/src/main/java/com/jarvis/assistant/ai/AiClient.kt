package com.jarvis.assistant.ai

import com.jarvis.assistant.command.ActionPlanner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Per-request tuning derived from the AI Performance settings. */
data class AiOptions(
    val maxTokens: Int = 300,
    val temperature: Double = 0.3,
    val connectMs: Int = 8000,
    val readMs: Int = 20000,
    /** One sentence appended to the system prompt that controls answer length. */
    val lengthHint: String = ""
)

/** Minimal client for any OpenAI-compatible /chat/completions endpoint (Groq, local server, self-hosted...). Uses the endpoint, key and model already saved in Settings. */
object AiClient {
    /** Plain conversation. */
    suspend fun chat(
        endpoint: String, apiKey: String, model: String, userName: String,
        turns: List<Pair<String, String>>, userText: String, options: AiOptions = AiOptions(maxTokens = 160, temperature = 0.3)
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val system = "You are FRIDAY, a concise voice assistant. Reply in the user's language (Hindi/Hinglish/English) in at most two short sentences." +
                if (userName.isNotBlank()) " Address the user as $userName." else ""
            post(endpoint, apiKey, model, buildMessages(system, turns, userText), options)
        }
    }

    /**
     * Conversation + structured action request. The model replies with one JSON object (see [ActionPlanner]);
     * the caller validates it against the allowlist before anything is executed. Same endpoint/key/model as [chat].
     */
    suspend fun plan(
        endpoint: String, apiKey: String, model: String, userName: String,
        turns: List<Pair<String, String>>, userText: String, context: String, options: AiOptions = AiOptions()
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val system = ActionPlanner.SYSTEM_PROMPT +
                (if (userName.isNotBlank()) "\nAddress the user as $userName in CHAT replies." else "") +
                (if (options.lengthHint.isNotBlank()) "\n${options.lengthHint}" else "") +
                "\nCurrent context (JSON): $context"
            post(endpoint, apiKey, model, buildMessages(system, turns, userText), options)
        }
    }

    /**
     * Opens the TCP/TLS connection to the AI host ahead of the first question so it can be reused (HTTP keep-alive).
     * This is NOT an AI request: no prompt is sent and nothing is billed. Failures are ignored.
     */
    suspend fun warmUp(endpoint: String) = withContext(Dispatchers.IO) {
        try {
            val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "HEAD"; connectTimeout = 3000; readTimeout = 3000
            }
            conn.responseCode
            conn.inputStream?.close()
        } catch (_: Exception) { /* purely an optimisation */ }
    }

    private fun buildMessages(system: String, turns: List<Pair<String, String>>, userText: String): JSONArray {
        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", system))
        turns.forEach {
            msgs.put(JSONObject().put("role", "user").put("content", it.first))
            msgs.put(JSONObject().put("role", "assistant").put("content", it.second))
        }
        msgs.put(JSONObject().put("role", "user").put("content", userText))
        return msgs
    }

    /**
     * The API key is only ever placed in the Authorization header: never logged, never put in an error message.
     * The connection is NOT force-closed after a successful read, so Android's HTTP stack can keep it alive and reuse it
     * for the next request (saves a TLS handshake per question).
     */
    private fun post(endpoint: String, apiKey: String, model: String, msgs: JSONArray, o: AiOptions): String {
        val body = JSONObject().put("messages", msgs).apply {
            if (model.isNotBlank()) put("model", model)
            put("temperature", o.temperature)
            put("max_tokens", o.maxTokens)
        }
        val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = o.connectMs; readTimeout = o.readMs; doOutput = true
            setRequestProperty("Content-Type", "application/json")
            if (apiKey.isNotBlank()) setRequestProperty("Authorization", "Bearer $apiKey")
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            if (conn.responseCode !in 200..299) {
                try { conn.errorStream?.close() } catch (_: Exception) {}
                throw IOException("HTTP ${conn.responseCode}")
            }
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            return JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
        } catch (e: IOException) {
            conn.disconnect()   // a failed connection must not be reused
            throw e
        }
    }
}
