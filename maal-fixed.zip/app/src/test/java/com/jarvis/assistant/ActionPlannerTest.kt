package com.jarvis.assistant

import com.jarvis.assistant.command.ActionPlanner
import com.jarvis.assistant.command.Cmd
import com.jarvis.assistant.command.Plan
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ActionPlannerTest {
    @Test fun chatReply() {
        assertEquals(Plan.Reply("Delhi India ki rajdhani hai."),
            ActionPlanner.parse("{\"type\":\"CHAT\",\"reply\":\"Delhi India ki rajdhani hai.\"}"))
    }
    @Test fun plainTextIsStillAChatReply() {
        assertEquals(Plan.NotJson("Namaste, kaise ho?"), ActionPlanner.parse("Namaste, kaise ho?"))
    }
    @Test fun jsonInsideCodeFence() {
        val p = ActionPlanner.parse("```json\n{\"type\":\"NAVIGATE\",\"action\":\"back\"}\n```")
        assertEquals(Plan.Run(Cmd.Back), p)
    }
    @Test fun whatsAppSendAlwaysGoesThroughLocalConfirmation() {
        val p = ActionPlanner.parse("{\"type\":\"WHATSAPP_SEND_MESSAGE\",\"recipient\":\"Kartavya\",\"message\":\"Hi\",\"requires_confirmation\":false}")
        assertEquals(Plan.Run(Cmd.WhatsApp("Kartavya", "Hi")), p)
    }
    @Test fun missingRecipientUsesChatContext() {
        val p = ActionPlanner.parse("{\"type\":\"WHATSAPP_SEND_MESSAGE\",\"recipient\":\"\",\"message\":\"Hi\"}")
        assertEquals(Plan.Run(Cmd.WhatsAppToContext("Hi")), p)
    }
    @Test fun unknownOrDangerousTypesAreRejected() {
        assertTrue(ActionPlanner.parse("{\"type\":\"RUN_SHELL\",\"cmd\":\"rm -rf /\"}") is Plan.Rejected)
        assertTrue(ActionPlanner.parse("{\"type\":\"CONFIRM\"}") is Plan.Rejected)
        assertTrue(ActionPlanner.parse("{\"type\":\"SCROLL\",\"direction\":\"SIDEWAYS\"}") is Plan.Rejected)
        assertTrue(ActionPlanner.parse("{\"type\":\"TYPE_TEXT\"}") is Plan.Rejected)
    }
    @Test fun deviceActions() {
        assertEquals(Plan.Run(Cmd.Volume(1)), ActionPlanner.parse("{\"type\":\"VOLUME\",\"direction\":\"UP\"}"))
        assertEquals(Plan.Run(Cmd.Torch(false)), ActionPlanner.parse("{\"type\":\"TORCH\",\"state\":\"OFF\"}"))
        assertEquals(Plan.Run(Cmd.OpenSettings("wifi")), ActionPlanner.parse("{\"type\":\"OPEN_SETTINGS\",\"screen\":\"WIFI\"}"))
        assertEquals(Plan.Run(Cmd.OpenApp("youtube")), ActionPlanner.parse("{\"type\":\"OPEN_APP\",\"app\":\"YouTube\"}"))
    }
}
