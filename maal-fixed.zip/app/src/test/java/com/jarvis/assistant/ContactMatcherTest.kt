package com.jarvis.assistant

import com.jarvis.assistant.command.ContactEntry
import com.jarvis.assistant.command.ContactMatcher
import com.jarvis.assistant.command.PhoneUtil
import com.jarvis.assistant.data.Prefs
import com.jarvis.assistant.data.WaSendMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ContactMatcherTest {
    private val contacts = listOf(
        ContactEntry("1", "Rahul Sharma", "98765 43210", 2),
        ContactEntry("2", "Rahul Verma", "+91 99999 11111", 2),
        ContactEntry("3", "Kartavya", "9000000001", 2),
        ContactEntry("3", "Kartavya", "0141-2345678", 3),
        ContactEntry("5", "Priya", "9111111111", 2)
    )

    @Test fun phoneNumbers() {
        assertEquals("919876543210", PhoneUtil.toWaNumber("98765 43210", "91"))
        assertEquals("919999911111", PhoneUtil.toWaNumber("+91 99999 11111", "91"))
        assertEquals("919876543210", PhoneUtil.toWaNumber("09876543210", "91"))
        assertEquals("919876543210", PhoneUtil.toWaNumber("00919876543210", "91"))
        assertNull(PhoneUtil.toWaNumber("123", "91"))
        assertNull(PhoneUtil.toWaNumber("abc", "91"))
    }

    @Test fun duplicateFirstNamesAreAmbiguous() {
        assertEquals(2, ContactMatcher.find(contacts, "rahul", false, "91").size)
        assertEquals(1, ContactMatcher.find(contacts, "rahul sharma", false, "91").size)
    }

    @Test fun contactWithSeveralNumbersPrefersMobile() {
        val hits = ContactMatcher.find(contacts, "kartavya", false, "91")
        assertEquals(1, hits.size)
        assertEquals("9000000001", hits[0].number)
    }

    @Test fun misspelledNamesMatchOnlyWhenSmart() {
        assertEquals(1, ContactMatcher.find(contacts, "priyaa", false, "91").size)
        assertTrue(ContactMatcher.find(contacts, "priyaa", true, "91").isEmpty())
        assertTrue(ContactMatcher.find(contacts, "zzzz", false, "91").isEmpty())
    }

    @Test fun splitsNameFromMessage() {
        val r = ContactMatcher.splitRecipient(contacts, "Rahul Sharma hello bhai", false, "91")
        assertEquals("Rahul Sharma" to "hello bhai", r)
    }

    @Test fun autoSendAlwaysRequiresConfirmation() {
        val p = Prefs(waSendMode = WaSendMode.AUTO_SEND, waConfirm = false).validated()
        assertTrue(p.waConfirm)
        assertEquals(30, Prefs(listenTimeoutSec = 99).validated().listenTimeoutSec)
        assertEquals("91", Prefs(countryCode = "x").validated().countryCode)
        assertEquals("en", Prefs(recogLang = "hinglish").voskLang())
    }
}
