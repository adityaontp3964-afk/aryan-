# PROGRESS / TEST REPORT (FRIDAY full phone control upgrade)

Legend: A = compiled · B = unit-tested · C = integration-tested · D = tested on a physical phone

## A. Compiled — NOT DONE
No Kotlin compiler, Gradle or Android SDK existed in the authoring environment (and no network). Nothing was compiled. The GitHub Actions run is the first real compile; compile errors are possible.

## B. Unit-tested — NOT RUN
`CommandParserTest` and `ActionPlannerTest` exist but were never executed (they run in the workflow *after* the APK is built).

## What WAS actually checked
- Python ports of `Normalizer` and the new parser branches, using the regexes extracted verbatim from `CommandParser.kt`: 23+ phrases behave as intended (pronoun follow-ups, "kartavya ki chat kholo", typing/dictation, scroll/recents/refresh/clear/search, "type of phone..." not typed). The Devanagari word table was not covered.
- XML resources/manifest are well-formed; workflow YAML parses; brace/parenthesis balance of every .kt file; a heuristic scan for unresolved symbols; every `Cmd` subclass is handled in the dispatcher's `when`.

## C/D. Integration / physical device — NOT DONE
Nothing involving Groq, the Accessibility Service, WhatsApp, TTS, wake word or the microphone was run. WhatsApp automation is **implemented but untested**; its screen selectors (Search entry, message box hint, Send label, chat title) are best-effort and may need adjusting for your WhatsApp version/language.

## Implemented (untested)
Accessibility: foreground package, find/click, type (refuses passwords), clear, search submit, scroll, Back/Home/Recents/Lock, gestures. AI→action planner with allowlist validation. Hybrid: local parser first (works offline); AI only for unrecognised input. WhatsApp: open chat by search with ambiguity question, pronoun context ("usko", 10-minute memory), confirmation before sending, post-send screen verification. New commands: recents, scroll, refresh, typing, dictation, clear, search, camera/gallery/calculator/dialer. Status model + dashboard rows (internet, recognition status, last command, last action result, accessibility connected, AI status).
Groq: endpoint/key/model/AI client reused; `AiClient.chat` unchanged; new `AiClient.plan` uses the same settings.

## Not implemented / limits
Phone calls (not requested as required; no CALL permission added) · payments/passwords (refused by design) · verifying page refresh · message delivery ticks · Devanagari→Latin contact matching · cloud TTS.

## Upgrade pass (voice accuracy, WhatsApp fix, latency, settings)

**Build status: NOT compiled or run.** This pass was written in an environment without Gradle, the Android SDK, a Kotlin
compiler or network access. Brace/bracket balance and the WhatsApp phrase logic were checked (the latter via a Python port),
but nothing has been compiled, unit-tested or run on a device. Push to GitHub and let the Actions build/tests run; fix any
compile error first. Treat every item below as "implemented, unverified on device".

### WhatsApp (root causes found and fixed)
- The parser matched on the *normalised* text, so the message was lower-cased and lost punctuation and words like "bhai/yaar/ji/please",
  and single-word names only. Now `WhatsAppParser` matches on cleaned tokens but cuts name and text from the ORIGINAL words.
- Any sentence containing "message" was hijacked; any "bye/stop" in a message stopped the assistant. Fixed (WhatsApp is parsed before Stop; narrower fallback).
- Contacts: fuzzy matching (`ContactMatcher`), duplicate names / several numbers -> the assistant asks which one; mobile number preferred.
- Opening: Contacts + official `https://wa.me/<number>?text=` link (no UI search needed). WhatsApp search via Accessibility remains the fallback.
- Three distinct outcomes: chat opened / message PREPARED (`MESSAGE_PREPARED`, "bheja NAHI hai") / SENT (only after Send pressed and the bubble seen on screen).
- Voice confirmation before any automatic send; the text in the box is verified to equal the message before Send is pressed.

### Voice / latency / behaviour
- Language: English, Hindi, Hinglish (online: en-IN/hi-IN + extra-language hint), n-best reranking by command grammar, confidence gate, pause tolerance (online hints + offline debounce), listening timeout, noise mode, wake sensitivity, continuous listening.
- Latency: Vosk models cached per process, TTS waits for engine init instead of dropping the first reply, HTTP keep-alive + connection warm-up, command execution moved off the main thread, AI max-tokens/timeouts/context by settings.
- Multi-step: chained commands ("YouTube kholo aur Arijit Singh search karo"), follow-ups from current app ("search karo X" on YouTube), "Ab kya karun?" after opening an app, "bas / ho gaya / rehne do" ends a task.
- Android: mic permission re-checked before listening, audio focus around speech, models freed on memory trim, no repeated identical spoken error.
- Settings (inside the existing SYSTEM/Settings tab): VOICE CONTROLS, AI PERFORMANCE, WHATSAPP, ASSISTANT BEHAVIOUR panels, a HINGLISH chip, wake sensitivity in WAKE WORD. All persisted, validated (`Prefs.validated`).

### Known limits
- Android gives apps no microphone gain / noise-suppression control; "noise handling" only changes how strictly results are accepted.
- Online recogniser may ignore silence-length and extra-language hints; Vosk has no Hinglish model (English model is used offline).
- Devanagari contact names are only matched if the contact is saved in Devanagari.
- WhatsApp gives no delivery receipt API; "sent" means Send was pressed and the new message bubble appeared.
- Auto-send needs the Accessibility service; without it the message is only prepared.
